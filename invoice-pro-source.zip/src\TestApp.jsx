import React from 'react';

function TestApp() {
  return (
    <div style={{ padding: '20px', backgroundColor: 'red', color: 'white', fontSize: '24px' }}>
      <h1>TEST PAGE - This should be visible!</h1>
      <p>If you can see this, React is working.</p>
    </div>
  );
}

export default TestApp;
